../images/half-life-edge1.png :

real	0m0.202s
user	0m0.169s
sys	0m0.033s

../images/half-life-edge2.png :

real	0m1.255s
user	0m0.803s
sys	0m0.452s

../images/medalion-edge1.png :

real	0m0.043s
user	0m0.039s
sys	0m0.004s

../images/medalion-edge2.png :

real	0m0.378s
user	0m0.231s
sys	0m0.147s

../images/nyc-edge1.png :

real	0m0.059s
user	0m0.059s
sys	0m0.000s

../images/nyc-edge2.png :

real	0m0.295s
user	0m0.191s
sys	0m0.103s

