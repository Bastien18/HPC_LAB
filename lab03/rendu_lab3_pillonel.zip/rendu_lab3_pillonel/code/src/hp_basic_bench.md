| Command | Mean [µs] | Min [µs] | Max [µs] | Relative |
|:---|---:|---:|---:|---:|
| `./lab01 "$filename" "${filename%.png}-edge$i.png" $i 10` | 771.4 ± 331.6 | 0.0 | 1547.2 | 1.00 |
